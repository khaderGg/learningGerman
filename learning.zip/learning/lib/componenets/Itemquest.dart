import 'package:flutter/material.dart';

import '../model/number.dart';
import '../model/question.dart';

class questionnn extends StatelessWidget {
  questionnn({super.key, required this.numberofI, required this.color});
  final numbersss numberofI;
  final Color color;
  @override
  Widget build(BuildContext context) {
    return Container(
      color: color,
      height: 100,
      child: Row(children: [
        Padding(
          padding: const EdgeInsets.only(left: 22),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(numberofI.gernumber, style: TextStyle(fontSize: 26)),
              Text(numberofI.numbers, style: TextStyle(fontSize: 20))
            ],
          ),
        ),
        Spacer(flex: 1),
        IconButton(onPressed: () {}, icon: Icon(Icons.play_circle))
      ]),
    );
  }
}
