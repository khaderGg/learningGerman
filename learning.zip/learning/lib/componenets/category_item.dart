import 'package:flutter/material.dart';

class cata extends StatelessWidget {
  cata({this.color, this.name, this.ontap});
  String? name;
  Color? color;
  Function()? ontap;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: GestureDetector(
        onTap: ontap,
        child: Container(
          decoration: BoxDecoration(
              border: Border.all(color: Colors.white, width: 2), color: color),
          alignment: Alignment.center,
          width: double.infinity,
          // color: color,
          child: Text(name!, style: TextStyle(fontSize: 22)),
        ),
      ),
    );
  }
}
