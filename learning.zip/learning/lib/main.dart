import 'package:flutter/material.dart';
import 'package:learning/screens/HomePage.dart';

void main() {
  runApp(const lerning());
}

class lerning extends StatelessWidget {
  const lerning({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}
