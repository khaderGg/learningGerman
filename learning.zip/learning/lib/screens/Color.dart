import 'package:flutter/material.dart';

import '../componenets/numberclass.dart';
import '../model/number.dart';

class colorpage extends StatelessWidget {
  colorpage({super.key});
  final List<number> numberrs = [
    number(
        gernumber: 'Rot', imagee: "assets/photo/color/download.png", numbers: 'Red'),
    number(gernumber: 'Orange', imagee: "assets/photo/color/download.jpeg", numbers: 'Orange'),
    number(gernumber: 'Dunkelblau', imagee: "assets/photo/color/download (1).jpeg", numbers: 'Dark blue'),
    number(
        gernumber: 'Gelb', imagee: "assets/photo/color/download (1).png", numbers: 'Yellow'),
    number(
        gernumber: 'Grün', imagee: "assets/photo/color/download (2).png", numbers: 'Green'),
    number(
        gernumber: 'Blau', imagee: "assets/photo/color/download (3).png", numbers: 'Blue'),
    number(gernumber: 'lila', imagee: "assets/photo/color/download (5).png", numbers: 'Purple'),

    number(
        gernumber: 'hellblau', imagee: "assets/photo/color/download (4).png", numbers: 'Light blue'),
    ];
  // Red – rot.
  // Orange – orange.
  // Yellow – gelb.
  // Green – grün.
  // Blue – blau.
  // Light blue – hellblau.
  // Dark blue – dunkelblau.
  // Purple – lila.
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        title: Text("Color"),
        centerTitle: true,
      ),
      body: ListView.builder(
        itemCount: numberrs.length,
        itemBuilder: (context, index) {
          return Item(
            numberofI: numberrs[index],
            color: Colors.redAccent,
          );
        },
      ),
    );
  }
}
