import 'package:flutter/material.dart';
import 'package:learning/screens/Color.dart';
import 'package:learning/screens/family.dart';
import 'package:learning/screens/number.dart';

import '../componenets/category_item.dart';
import 'Question.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.red,
          title: const Text("Learning german"),
          centerTitle: true,
        ),
        body: Container(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: GridView(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3, crossAxisSpacing: 2),
              children: [
                cata(
                  color: Colors.red,
                  name: "Number",
                  ontap: () {
                    Navigator.push(context, MaterialPageRoute(
                      builder: (context) {
                        return numbers();
                      },
                    ));
                  },
                ),
                cata(
                  color: Colors.red,
                  name: "Family",
                  ontap: () {
                    Navigator.push(context, MaterialPageRoute(
                      builder: (context) {
                        return familypage();
                      },
                    ));
                  },
                ),
                cata(
                  color: Colors.red,
                  name: "Color",
                  ontap: () {
                    Navigator.push(context, MaterialPageRoute(
                      builder: (context) {
                        return colorpage();
                      },
                    ));
                  },
                ),
                cata(
                  color: Colors.red,
                  name: "Question",
                  ontap: () {
                    Navigator.push(context, MaterialPageRoute(
                      builder: (context) {
                        return questionpage();
                      },
                    ));
                  },
                ),
              ],
            ),
          ),
        ));
  }
}
