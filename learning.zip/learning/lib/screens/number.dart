import 'package:flutter/material.dart';
import 'package:learning/componenets/numberclass.dart';
import 'package:learning/model/number.dart';

import '../model/number.dart';

class numbers extends StatelessWidget {
  numbers({super.key});
  final List<number> numberrs = [
    number(
        gernumber: 'null', imagee: "assets/photo/zero.jpeg", numbers: 'zero'),
    number(gernumber: 'eins', imagee: "assets/photo/one.png", numbers: 'one'),
    number(gernumber: 'zwei', imagee: "assets/photo/two.webp", numbers: 'two'),
    number(
        gernumber: 'drei', imagee: "assets/photo/three.webp", numbers: 'three'),
    number(
        gernumber: 'vier', imagee: "assets/photo/four.jpeg", numbers: 'four'),
    number(
        gernumber: 'fünf', imagee: "assets/photo/five.webp", numbers: 'five'),
    number(gernumber: 'sechs', imagee: "assets/photo/six.webp", numbers: 'six'),
    number(
        gernumber: 'sieben',
        imagee: "assets/photo/seven.webp",
        numbers: 'seven'),
    number(
        gernumber: 'acht', imagee: "assets/photo/eight.webp", numbers: 'eight'),
    number(
        gernumber: 'neun', imagee: "assets/photo/nine.webp", numbers: 'nine'),
  ];
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.red,
          title: Text("Number"),
          centerTitle: true,
        ),
        body: ListView.builder(
          itemCount: numberrs.length,
          itemBuilder: (context, index) {
            return Item(
              numberofI: numberrs[index],
              color: Colors.redAccent,
            );
          },
        ),
      ),
    );
  }
}
