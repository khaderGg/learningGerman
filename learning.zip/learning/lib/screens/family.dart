import 'package:flutter/material.dart';

import '../componenets/numberclass.dart';
import '../model/number.dart';

class familypage extends StatelessWidget {
  familypage({super.key});
  final List<number> familyp = [
    number(
        gernumber: 'die Mutter',
        imagee: "assets/photo/family/download.jpeg",
        numbers: 'The mother'),
    number(
        gernumber: 'der Vater',
        imagee: "assets/photo/family/father.jpeg",
        numbers: 'The father'),
    number(
        gernumber: 'der Bruder',
        imagee: "assets/photo/family/brother.jpeg",
        numbers: 'The brother'),
    number(
        gernumber: 'die Schwester',
        imagee: "assets/photo/family/sister.jpeg",
        numbers: 'The sister'),
    number(
        gernumber: 'der GroBvater',
        imagee: "assets/photo/family/grandba.jpeg",
        numbers: 'The Grandfather'),
    number(
        gernumber: 'die GroBmutter ',
        imagee: "assets/photo/family/grandma.png",
        numbers: 'The Grandmother'),
    number(
        gernumber: 'der Sohn',
        imagee: "assets/photo/family/son.jpeg",
        numbers: 'The Son'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        title: Text("Family"),
        centerTitle: true,
      ),
      body: ListView.builder(
        itemCount: familyp.length,
        itemBuilder: (context, index) {
          return Item(
            numberofI: familyp[index],
            color: Colors.redAccent,
          );
        },
      ),
    );
  }
}
