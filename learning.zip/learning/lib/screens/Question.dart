import 'package:flutter/material.dart';
import 'package:learning/componenets/Itemquest.dart';

import '../componenets/numberclass.dart';
import '../model/number.dart';
import '../model/question.dart';

class questionpage extends StatelessWidget {
  questionpage({super.key});
  final List<numbersss> ques = [
    numbersss(gernumber: 'Wie geht es dir?', numbers: ' how are you?'),
    numbersss(gernumber: ' Wo wohnst du?', numbers: ' Where do you live?'),
    numbersss(
        gernumber: 'AS MACHST DU GERADE?',
        numbers: 'WHAT ARE YOU DOING RIGHT NOW?'),
    numbersss(
        gernumber: ' Triffst du jemanden?', numbers: 'are you seeing someone?'),
    numbersss(gernumber: 'Bist du da?', numbers: 'are you there?'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.red,
          title: Text("Question"),
          centerTitle: true,
        ),
        body: ListView.builder(
          itemCount: ques.length,
          itemBuilder: (context, i) {
            return questionnn(
              numberofI:ques[i],
              color: Colors.red,


            );
          },
        ));
  }
}
