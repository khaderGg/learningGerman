class number {
  final String numbers;
  final String gernumber;
  final String imagee;
  number(
      {required this.gernumber, required this.imagee, required this.numbers});
}
