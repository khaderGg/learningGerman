class numbersss {
  final String numbers;
  final String gernumber;
  numbersss(
      {required this.gernumber,  required this.numbers});
}
