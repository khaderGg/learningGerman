package com.example.learning

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
